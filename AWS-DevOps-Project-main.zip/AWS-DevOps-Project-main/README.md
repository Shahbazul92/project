# AWS-DevOps-Project
![Logo](https://github.com/harshitsahu2311/AWS-DevOps-Project/blob/main/CodeCommit%20(1).gif)

For the detailed Steps: [Blog](https://harshitsahu2311.hashnode.dev/project-aws-devops-deployment)
